package org.example.repositorio;

import org.example.modelo.Pelicula;
import org.example.servicio.IRepositorio;

import java.sql.Connection;
import java.util.List;

public class RepositorioPelicula implements IRepositorio {

    private Connection conexion;

    public RepositorioPelicula() {
        this.conexion = conexion;
    }

    public void guardar(Pelicula pelicula){

    }

    public List<Pelicula> listar(){
        return null;
    }

    public void actualizar(Pelicula pelicula){

    }

    public void borrar(int i){

    }

}
